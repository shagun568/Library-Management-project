// Temporary Book Database using localStorage
let books = JSON.parse(localStorage.getItem("books")) || [
    { id: "101", name: "Java Basics", available: true },
    { id: "102", name: "Python Fundamentals", available: true }
];

// Save books to localStorage
function saveBooks() {
    localStorage.setItem("books", JSON.stringify(books));
}

// Show Success Message
function showSuccessMessage(msg) {
    let success = document.getElementById("successMsg");
    if(success){
        success.innerHTML = `✅ ${msg}`;
        setTimeout(() => { success.innerHTML = ""; }, 3000);
    }
}

// Login Validation
function loginCheck() {
    let user = document.getElementById("username").value;
    let pass = document.getElementById("password").value;
    let roles = document.getElementsByName("role");
    let selectedRole = "";

    for (let i = 0; i < roles.length; i++) {
        if (roles[i].checked) selectedRole = roles[i].value;
    }

    if (user === "" || pass === "" || selectedRole === "") {
        document.getElementById("error").innerHTML = "Fill all fields & select role";
        return false;
    }

    if (selectedRole === "admin") window.location.href = "admin.html";
    else window.location.href = "user.html";

    return false;
}

// Issue Book
function issueBook() {
    let id = document.getElementById("issueId").value;
    let msg = document.getElementById("issueMsg");
    msg.innerHTML = "";

    if (id === "") {
        msg.innerHTML = "Please enter Book ID";
        return;
    }

    let book = books.find(b => b.id === id);
    if (!book) msg.innerHTML = "Book not found";
    else if (!book.available) msg.innerHTML = "Book already issued";
    else {
        book.available = false;
        saveBooks();
        showSuccessMessage("Book issued successfully");
        document.getElementById("issueId").value = "";
    }
}

// Return Book
function returnBook() {
    let id = document.getElementById("returnId").value;
    let msg = document.getElementById("returnMsg");
    msg.innerHTML = "";

    if (id === "") {
        msg.innerHTML = "Please enter Book ID";
        return;
    }

    let book = books.find(b => b.id === id);
    if (!book) msg.innerHTML = "Book not found";
    else if (book.available) msg.innerHTML = "Book is already available";
    else {
        book.available = true;
        saveBooks();
        showSuccessMessage("Book returned successfully");
        document.getElementById("returnId").value = "";
    }
}

// Add Book in Maintenance
function addBook() {
    let id = document.getElementById("bookId").value;
    let name = document.getElementById("bookName").value;
    let success = document.getElementById("successMsg");

    if(id==="" || name==="") {
        alert("Fill all fields");
        return;
    }

    books.push({ id: id, name: name, available: true });
    saveBooks();
    showSuccessMessage("Book added successfully");
    document.getElementById("bookId").value="";
    document.getElementById("bookName").value="";
}